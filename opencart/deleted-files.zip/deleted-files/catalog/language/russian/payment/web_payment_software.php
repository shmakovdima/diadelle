<?php
// Text
$_['text_title']				= 'Кредитная / Дебетная карта (Web Payment Software)';
$_['text_credit_card']			= 'Информация о карте';

// Entry
$_['entry_cc_owner']			= 'Владелец карты:';
$_['entry_cc_number']			= 'Номер карты:';
$_['entry_cc_expire_date']		= 'Дата окончания действия:';
$_['entry_cc_cvv2']				= 'Card Security Code (CVV2)::::::::::::::::::::::::::::::::';

